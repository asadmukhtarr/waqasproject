// Demo 21 Js file
$(document).ready(function () {
    'use strict';

    // Notification

    $('.notify-action a').on('click', function() {
    	$('.notification').css('display', 'none');
    })
});